# -*- coding: utf-8 -*-
# @Time    : 2023/6/18 01:54
# @Author  : AI悦创
# @FileName: variable.py
# @Software: PyCharm
# @Blog    ：https://bornforthis.cn/
template = """1. 什么是变量？——变量就是在计算机的内存当中，开辟空间；
"""


def show():
    """
    此函数，用于输出 Python 变量的定义与特点。

    """
    print(template)
    return template
