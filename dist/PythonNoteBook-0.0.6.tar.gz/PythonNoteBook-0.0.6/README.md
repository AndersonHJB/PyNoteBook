# PynoteBook

```python
pip install --upgrade PythonNoteBook
```