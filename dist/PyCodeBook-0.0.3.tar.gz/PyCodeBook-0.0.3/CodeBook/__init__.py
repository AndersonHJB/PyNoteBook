# -*- coding: utf-8 -*-
# @Time    : 2023/6/18 01:44
# @Author  : AI悦创
# @FileName: __init__.py.py
# @Software: PyCharm
# @Blog    ：https://bornforthis.cn/
# from CodeBook.variable import variable
from CodeBook.variable import variable

